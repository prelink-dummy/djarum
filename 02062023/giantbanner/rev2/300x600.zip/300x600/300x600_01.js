(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.beritasupermotomin = function() {
	this.initialize(img.beritasupermotomin);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.BG_300x600min = function() {
	this.initialize(img.BG_300x600min);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.CTA_300x600minmin = function() {
	this.initialize(img.CTA_300x600minmin);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.LogoSA_300x600min = function() {
	this.initialize(img.LogoSA_300x600min);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.LogoSupermoto_300x600min = function() {
	this.initialize(img.LogoSupermoto_300x600min);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.Motor_300x600minmin2min = function() {
	this.initialize(img.Motor_300x600minmin2min);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.trans2minmin = function() {
	this.initialize(img.trans2minmin);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.trans3minmin = function() {
	this.initialize(img.trans3minmin);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.trans4minmin = function() {
	this.initialize(img.trans4minmin);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.trans6minmin = function() {
	this.initialize(img.trans6minmin);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_9
	this.instance = new lib.Motor_300x600minmin2min();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.logoSupermoto = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_15
	this.instance = new lib.LogoSupermoto_300x600min();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.LogoSA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_12
	this.instance = new lib.LogoSA_300x600min();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.info = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_17
	this.instance = new lib.CTA_300x600minmin();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.bg001 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.beritasupermotomin();
	this.instance.setTransform(-150,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-300,300,600);


(lib.BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_8
	this.instance = new lib.BG_300x600min();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.anip04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trans6minmin();
	this.instance.setTransform(-150,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-300,300,600);


(lib.anip3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trans4minmin();
	this.instance.setTransform(-150,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-300,300,600);


(lib.anip02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trans3minmin();
	this.instance.setTransform(-150,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-300,300,600);


(lib.anip01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trans2minmin();
	this.instance.setTransform(-150,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-300,300,600);


// stage content:
(lib._300x600_01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_7
	this.instance = new lib.anip04("synched",0);
	this.instance.setTransform(150,300);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(34).to({_off:false},0).to({_off:true},1).wait(205));

	// Layer_5
	this.instance_1 = new lib.anip3("synched",0);
	this.instance_1.setTransform(150,300);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(33).to({_off:false},0).to({_off:true},1).wait(206));

	// Layer_4
	this.instance_2 = new lib.anip02("synched",0);
	this.instance_2.setTransform(150,300);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(32).to({_off:false},0).to({_off:true},1).wait(207));

	// Layer_3
	this.instance_3 = new lib.anip01("synched",0);
	this.instance_3.setTransform(150,300);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).to({_off:true},1).wait(208));

	// Layer_22 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A8/0MMA7sgB0MgAJArTMg9RAAug");
	mask.setTransform(166.6,334.625);

	// info_copy
	this.instance_4 = new lib.info();
	this.instance_4.setTransform(150,442,1.3422,1.3422,0,0,0,150,442);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;
	new cjs.ButtonHelper(this.instance_4, 0, 1, 2, false, new lib.info(), 3);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(88).to({_off:false},0).to({regY:442.1,scaleX:1,scaleY:1,y:442.1,alpha:1},15,cjs.Ease.quintOut).to({scaleX:1.12,scaleY:1.12,x:150.05,y:442.15,alpha:0.5508},14,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1,x:150,y:442.1,alpha:1},14,cjs.Ease.quadInOut).to({scaleX:1.12,scaleY:1.12,x:150.05,y:442.15,alpha:0.5508},14,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1,x:150,y:442.1,alpha:1},14,cjs.Ease.quadInOut).to({scaleX:1.12,scaleY:1.12,x:150.05,y:442.15,alpha:0.5508},14,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1,x:150,y:442.1,alpha:1},14,cjs.Ease.quadInOut).to({scaleX:1.12,scaleY:1.12,x:150.05,y:442.15,alpha:0.5508},14,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1,x:150,y:442.1,alpha:1},14,cjs.Ease.quadInOut).to({scaleX:1.12,scaleY:1.12,x:150.05,y:442.15,alpha:0.5508},14,cjs.Ease.quadInOut).wait(1).to({regY:300,scaleX:1.1185,scaleY:1.1185,y:283.25,alpha:0.5565},0).wait(1).to({scaleX:1.1148,scaleY:1.1148,y:283.75,alpha:0.5703},0).wait(1).to({scaleX:1.1087,scaleY:1.1087,y:284.6,alpha:0.5934},0).wait(1).to({scaleX:1.0998,scaleY:1.0998,y:285.9,alpha:0.6271},0).wait(1).to({scaleX:1.088,scaleY:1.088,y:287.55,alpha:0.6714},0).wait(1).to({scaleX:1.0739,scaleY:1.0739,x:150.1,y:289.5,alpha:0.7246},0).wait(1).to({scaleX:1.0586,scaleY:1.0586,y:291.7,alpha:0.7825},0).wait(1).to({scaleX:1.0436,scaleY:1.0436,y:293.8,alpha:0.8391},0).wait(1).to({scaleX:1.0303,scaleY:1.0303,x:150.05,y:295.7,alpha:0.8891},0).wait(1).to({regY:442,scaleX:1.0195,scaleY:1.0195,x:150.1,y:442.05,alpha:0.9297},0).wait(1));

	// Layer_21 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A5EpNMAx1gBGIAUUJMgyJAAeg");
	mask_1.setTransform(151.575,546.1);

	// info
	this.instance_5 = new lib.info();
	this.instance_5.setTransform(150,489.8,1.7308,1.7308,0,0,0,150,489.9);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;
	new cjs.ButtonHelper(this.instance_5, 0, 1, 2, false, new lib.info(), 3);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(93).to({_off:false},0).to({regY:490.1,scaleX:1,scaleY:1,y:490.1,alpha:1},14,cjs.Ease.quintOut).wait(133));

	// Layer_19 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_35 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_58 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_59 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_60 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_61 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_62 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_63 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_64 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_65 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_66 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_67 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_68 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_69 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_70 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_71 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_72 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_73 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_74 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_75 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_76 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_77 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_78 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_119 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_122 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_124 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_125 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_126 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_127 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_130 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_131 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_132 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_133 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_134 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_135 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_136 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_137 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_138 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_139 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_193 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_194 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_195 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_196 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_197 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_198 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_199 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_200 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_201 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_202 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_203 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_204 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_205 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_206 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_207 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_208 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_209 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_210 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_211 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_212 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");
	var mask_2_graphics_213 = new cjs.Graphics().p("AA3rwIKUAAIr8XSIqZAPg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(35).to({graphics:mask_2_graphics_35,x:343.8252,y:37.2753}).wait(23).to({graphics:mask_2_graphics_58,x:-36.5252,y:37.2753}).wait(1).to({graphics:mask_2_graphics_59,x:-17.51,y:37.2753}).wait(1).to({graphics:mask_2_graphics_60,x:1.5048,y:37.2753}).wait(1).to({graphics:mask_2_graphics_61,x:20.52,y:37.2753}).wait(1).to({graphics:mask_2_graphics_62,x:39.5352,y:37.2753}).wait(1).to({graphics:mask_2_graphics_63,x:58.5499,y:37.2753}).wait(1).to({graphics:mask_2_graphics_64,x:77.5651,y:37.2753}).wait(1).to({graphics:mask_2_graphics_65,x:96.5799,y:37.2753}).wait(1).to({graphics:mask_2_graphics_66,x:115.5951,y:37.2753}).wait(1).to({graphics:mask_2_graphics_67,x:134.6098,y:37.2753}).wait(1).to({graphics:mask_2_graphics_68,x:153.625,y:37.2753}).wait(1).to({graphics:mask_2_graphics_69,x:172.6398,y:37.2753}).wait(1).to({graphics:mask_2_graphics_70,x:191.655,y:37.2753}).wait(1).to({graphics:mask_2_graphics_71,x:210.6702,y:37.2753}).wait(1).to({graphics:mask_2_graphics_72,x:229.685,y:37.2753}).wait(1).to({graphics:mask_2_graphics_73,x:248.7001,y:37.2753}).wait(1).to({graphics:mask_2_graphics_74,x:267.7149,y:37.2753}).wait(1).to({graphics:mask_2_graphics_75,x:286.7301,y:37.2753}).wait(1).to({graphics:mask_2_graphics_76,x:305.7448,y:37.2753}).wait(1).to({graphics:mask_2_graphics_77,x:324.7601,y:37.2753}).wait(1).to({graphics:mask_2_graphics_78,x:343.8252,y:37.2753}).wait(41).to({graphics:mask_2_graphics_119,x:-36.5252,y:37.2753}).wait(1).to({graphics:mask_2_graphics_120,x:-17.51,y:37.2753}).wait(1).to({graphics:mask_2_graphics_121,x:1.5048,y:37.2753}).wait(1).to({graphics:mask_2_graphics_122,x:20.52,y:37.2753}).wait(1).to({graphics:mask_2_graphics_123,x:39.5352,y:37.2753}).wait(1).to({graphics:mask_2_graphics_124,x:58.5499,y:37.2753}).wait(1).to({graphics:mask_2_graphics_125,x:77.5651,y:37.2753}).wait(1).to({graphics:mask_2_graphics_126,x:96.5799,y:37.2753}).wait(1).to({graphics:mask_2_graphics_127,x:115.5951,y:37.2753}).wait(1).to({graphics:mask_2_graphics_128,x:134.6098,y:37.2753}).wait(1).to({graphics:mask_2_graphics_129,x:153.625,y:37.2753}).wait(1).to({graphics:mask_2_graphics_130,x:172.6398,y:37.2753}).wait(1).to({graphics:mask_2_graphics_131,x:191.655,y:37.2753}).wait(1).to({graphics:mask_2_graphics_132,x:210.6702,y:37.2753}).wait(1).to({graphics:mask_2_graphics_133,x:229.685,y:37.2753}).wait(1).to({graphics:mask_2_graphics_134,x:248.7001,y:37.2753}).wait(1).to({graphics:mask_2_graphics_135,x:267.7149,y:37.2753}).wait(1).to({graphics:mask_2_graphics_136,x:286.7301,y:37.2753}).wait(1).to({graphics:mask_2_graphics_137,x:305.7448,y:37.2753}).wait(1).to({graphics:mask_2_graphics_138,x:324.7601,y:37.2753}).wait(1).to({graphics:mask_2_graphics_139,x:343.8252,y:37.2753}).wait(54).to({graphics:mask_2_graphics_193,x:-36.5252,y:37.2753}).wait(1).to({graphics:mask_2_graphics_194,x:-17.51,y:37.2753}).wait(1).to({graphics:mask_2_graphics_195,x:1.5048,y:37.2753}).wait(1).to({graphics:mask_2_graphics_196,x:20.52,y:37.2753}).wait(1).to({graphics:mask_2_graphics_197,x:39.5352,y:37.2753}).wait(1).to({graphics:mask_2_graphics_198,x:58.5499,y:37.2753}).wait(1).to({graphics:mask_2_graphics_199,x:77.5651,y:37.2753}).wait(1).to({graphics:mask_2_graphics_200,x:96.5799,y:37.2753}).wait(1).to({graphics:mask_2_graphics_201,x:115.5951,y:37.2753}).wait(1).to({graphics:mask_2_graphics_202,x:134.6098,y:37.2753}).wait(1).to({graphics:mask_2_graphics_203,x:153.625,y:37.2753}).wait(1).to({graphics:mask_2_graphics_204,x:172.6398,y:37.2753}).wait(1).to({graphics:mask_2_graphics_205,x:191.655,y:37.2753}).wait(1).to({graphics:mask_2_graphics_206,x:210.6702,y:37.2753}).wait(1).to({graphics:mask_2_graphics_207,x:229.685,y:37.2753}).wait(1).to({graphics:mask_2_graphics_208,x:248.7001,y:37.2753}).wait(1).to({graphics:mask_2_graphics_209,x:267.7149,y:37.2753}).wait(1).to({graphics:mask_2_graphics_210,x:286.7301,y:37.2753}).wait(1).to({graphics:mask_2_graphics_211,x:305.7448,y:37.2753}).wait(1).to({graphics:mask_2_graphics_212,x:324.7601,y:37.2753}).wait(1).to({graphics:mask_2_graphics_213,x:343.8252,y:37.2753}).wait(27));

	// Logo_SA_copy
	this.instance_6 = new lib.LogoSA();
	this.instance_6.setTransform(149.8,56.1,1.7336,1.7336,0,0,0,149.9,56.1);
	this.instance_6.alpha = 0;
	this.instance_6.compositeOperation = "lighter";
	this.instance_6._off = true;
	new cjs.ButtonHelper(this.instance_6, 0, 1, 2, false, new lib.LogoSA(), 3);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(65).to({_off:false},0).to({regX:150,scaleX:1,scaleY:1,x:150,alpha:1},15,cjs.Ease.quintOut).wait(160));

	// Logo_SA
	this.instance_7 = new lib.LogoSA();
	this.instance_7.setTransform(149.8,56.1,1.7336,1.7336,0,0,0,149.9,56.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;
	new cjs.ButtonHelper(this.instance_7, 0, 1, 2, false, new lib.LogoSA(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(65).to({_off:false},0).to({regX:150,scaleX:1,scaleY:1,x:150,alpha:1},15,cjs.Ease.quintOut).wait(160));

	// Symbol_1
	this.instance_8 = new lib.Symbol1();
	this.instance_8.setTransform(149.95,300.1,1.4067,1.4067,0,0,0,149.9,300);
	this.instance_8._off = true;
	new cjs.ButtonHelper(this.instance_8, 0, 1, 2, false, new lib.Symbol1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(35).to({_off:false},0).to({scaleX:1.3864,scaleY:1.3864,x:158,y:310.6},1,cjs.Ease.quadInOut).to({regX:149.8,scaleX:1.3559,scaleY:1.3559,x:149.9,y:286.2},3,cjs.Ease.quadInOut).to({regY:299.9,scaleX:1.3355,scaleY:1.3355,x:159.9,y:299.35},2,cjs.Ease.quadInOut).to({regY:300,scaleX:1.305,scaleY:1.305,x:149.9,y:314.2},3,cjs.Ease.quadInOut).to({regY:299.9,scaleX:1.2542,scaleY:1.2542,x:151.9,y:292.05},5,cjs.Ease.quadInOut).to({scaleX:1.2134,scaleY:1.2134,x:149.95,y:306.15},4,cjs.Ease.quadInOut).to({scaleX:1.1626,scaleY:1.1626,x:150,y:296.15},5,cjs.Ease.quadInOut).to({scaleX:1.1016,scaleY:1.1016,x:150.05,y:304.15},6,cjs.Ease.quadInOut).to({scaleX:1.0508,scaleY:1.0508,y:298.15},6,cjs.Ease.quadInOut).to({regX:150,regY:300,scaleX:1,scaleY:1,x:150,y:304},5,cjs.Ease.quadInOut).to({scaleX:1.0006,scaleY:1.0006,x:143.15,y:303.15},6,cjs.Ease.quadInOut).to({scaleX:1.0013,scaleY:1.0013,x:146.25,y:298.25},6,cjs.Ease.quadInOut).to({regY:300.1,scaleX:1.0019,scaleY:1.0019,x:147.35,y:305.4},6,cjs.Ease.quadInOut).to({regY:300,scaleX:1.0028,scaleY:1.0028,x:146,y:300.05},8,cjs.Ease.quadInOut).to({scaleX:1.0055,scaleY:1.0055,x:150.05,y:296.05},6,cjs.Ease.quadInOut).to({regY:299.9,scaleX:1.0088,scaleY:1.0088,y:304},7,cjs.Ease.quadInOut).to({scaleX:1.0125,scaleY:1.0125,y:296},8,cjs.Ease.quadInOut).to({scaleX:1.0157,scaleY:1.0157,x:148.1,y:304},7,cjs.Ease.quadInOut).to({scaleX:1.0189,scaleY:1.0189,y:300},7,cjs.Ease.quadInOut).to({regX:150.1,scaleX:1.0222,scaleY:1.0222,x:150.2,y:306.1},7,cjs.Ease.quadInOut).to({scaleX:1.0254,scaleY:1.0254,x:150.25,y:298.1},7,cjs.Ease.quadInOut).to({scaleX:1.0291,scaleY:1.0291,x:152.25,y:302.15},8,cjs.Ease.quadInOut).to({regX:150,scaleX:1.0323,scaleY:1.0323,x:146.2,y:296.25},7,cjs.Ease.quadInOut).to({regY:299.8,scaleX:1.0351,scaleY:1.0351,x:154.2,y:300.15},6,cjs.Ease.quadInOut).to({scaleX:1.0388,scaleY:1.0388,x:150.2,y:306.2},8,cjs.Ease.quadInOut).to({scaleX:1.0425,scaleY:1.0425,y:304.15},8,cjs.Ease.quadInOut).to({scaleX:1.0444,scaleY:1.0444,x:150.25,y:296.2},4,cjs.Ease.quadInOut).to({scaleX:1.0481,scaleY:1.0481,x:146.25,y:300.2},8,cjs.Ease.quadInOut).to({regX:149.9,scaleX:1.0523,scaleY:1.0523,x:154.2},9,cjs.Ease.quadInOut).to({regY:299.7,scaleX:1.0546,scaleY:1.0546,x:150.2,y:304.1},5,cjs.Ease.quadInOut).to({regX:149.8,scaleX:1.0593,scaleY:1.0593,x:146.1,y:300.1},10,cjs.Ease.quadInOut).to({scaleX:1.0626,scaleY:1.0626,x:150,y:296.1},7,cjs.Ease.quadInOut).to({regX:150,regY:299.9,scaleX:1.0668,scaleY:1.0668,x:150.05,y:299.9},9,cjs.Ease.quadInOut).wait(1));

	// logo_Supermoto
	this.instance_9 = new lib.logoSupermoto();
	this.instance_9.setTransform(6,168,0.4281,0.4281,0,0,0,6,168);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;
	new cjs.ButtonHelper(this.instance_9, 0, 1, 2, false, new lib.logoSupermoto(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(79).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},15,cjs.Ease.quintOut).wait(146));

	// BG
	this.instance_10 = new lib.BG();
	this.instance_10.setTransform(150,300,1,1,0,0,0,150,300);
	this.instance_10._off = true;
	new cjs.ButtonHelper(this.instance_10, 0, 1, 2, false, new lib.BG(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(35).to({_off:false},0).to({scaleX:1.2938,scaleY:1.0667,x:150.1,y:300.05},204).wait(1));

	// Layer_1
	this.instance_11 = new lib.bg001("synched",0);
	this.instance_11.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(240));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgY/gwbMAx/AAAMAAABg3Mgx/AAAg");
	this.shape.setTransform(150,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgY/AwcMAAAhg3MAx/AAAMAAABg3g");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(240));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(40,178.1,370.1,821);
// library properties:
lib.properties = {
	id: '9CF177315B1A2246AE431E9489F9CA2A',
	width: 300,
	height: 600,
	fps: 15,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/beritasupermotomin.jpg?1685689923190", id:"beritasupermotomin"},
		{src:"images/BG_300x600min.jpg?1685689923190", id:"BG_300x600min"},
		{src:"images/CTA_300x600minmin.png?1685689923190", id:"CTA_300x600minmin"},
		{src:"images/LogoSA_300x600min.png?1685689923190", id:"LogoSA_300x600min"},
		{src:"images/LogoSupermoto_300x600min.png?1685689923190", id:"LogoSupermoto_300x600min"},
		{src:"images/Motor_300x600minmin2min.png?1685689923190", id:"Motor_300x600minmin2min"},
		{src:"images/trans2minmin.jpg?1685689923190", id:"trans2minmin"},
		{src:"images/trans3minmin.jpg?1685689923190", id:"trans3minmin"},
		{src:"images/trans4minmin.jpg?1685689923190", id:"trans4minmin"},
		{src:"images/trans6minmin.jpg?1685689923190", id:"trans6minmin"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9CF177315B1A2246AE431E9489F9CA2A'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;